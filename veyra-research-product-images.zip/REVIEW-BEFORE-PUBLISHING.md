# Veyra Research product images: review before publishing

These images follow the brief: labels show only the Veyra Research logo, the product name, a generic descriptor, and research-use lines. Nothing below is printed on any label until you confirm it.

## Needs your confirmation

1. **Product list and spelling.** The 12 products come from the Veyra website draft, not from a list you supplied: Retatrutide, Tirzepatide, Semaglutide, Cagrilintide, BPC-157, TB-500, GHK-Cu, NAD+, MOTS-c, Ipamorelin, Semax, Selank. Confirm each one is actually in your catalog and spelled the way you want.
2. **Strengths.** Labels deliberately show no mg amount. The website draft lists sizes (for example Retatrutide 10/20/30/60 mg) that you haven't verified. Send the verified strengths and I can add a strength line and one image per strength.
3. **Lot numbers.** No lot field is shown. If you want one, send the format (for example "LOT VR-0000") and whether it should be blank or filled.
4. **Descriptor wording.** Labels say "Research peptide". NAD+ says "Research compound" because it isn't a peptide.
5. **Legal wording.** Labels and cartons say "For research use only" and "Not for human consumption". Have this checked against the rules where you sell.
6. **Category accents.** The thin label stripe color follows the website's four categories (Metabolic, Recovery, Longevity, Signalling). Confirm the category assignments.

## Older assets to retire or update

- **Earlier image sets** (pastel caps and labels) print "≥99% purity", strengths, molecular data and storage text that you haven't verified. Don't publish them.
- **Higgsfield hero shots** use the old pastel caps and an AI-drawn label. They no longer match this palette.
- **The website draft** still uses the pastel theme and shows purity claims, sizes and prices. It needs updating to match these images and your verified catalog.
- **The logo** is the existing Veyra mark (teal with a yellow point), kept as the brief asks. It's the only saturated color on the packaging.
